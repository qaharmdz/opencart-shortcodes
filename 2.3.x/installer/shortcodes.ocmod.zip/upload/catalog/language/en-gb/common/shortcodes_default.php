<?php

// Shortcode login
$_['login_message']         = 'Please <a href="%s">login</a> to read the rest of the post.';
$_['login_group']           = 'Your customer group is not permitted to read the rest of the post. Please <a href="%s">contact us</a> for further info.';

// Shortcode image_modal
$_['imgModal_caption']      = 'Click to enlarge.';
?>